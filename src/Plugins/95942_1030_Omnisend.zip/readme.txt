1. 'Nop.Plugin.Misc.Omnisend' directory contains source code.
2. 'Misc.Omnisend' contains binaries. Just drop it into \Plugins directory on your server.